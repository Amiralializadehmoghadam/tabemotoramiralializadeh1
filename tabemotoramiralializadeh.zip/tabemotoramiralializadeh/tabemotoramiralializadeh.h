#ifndef tabemotoramiralializadeh_H
#define tabemotoramiralializadeh_H

#include <Arduino.h>

void tabemotoramiralializadeh();

#endif